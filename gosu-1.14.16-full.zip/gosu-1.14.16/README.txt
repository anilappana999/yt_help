WELCOME

Thanks for downloading Gosu.  You are using version 1.14.16.


QUICKSTART

1. Set the JAVA_HOME environment variable to JDK 1.8's home, if needed

2. Go to the bin folder and double click on gosu.cmd (or gosu if you are using Linux/Mac)

You can try the bundled example projects like the Life game. Just select Life from the Examples pane and run the game by pressing F5.

The Gosu Plugin for IntelliJ is the recommended way to use Gosu.
The plugin is hosted on the IntelliJ IDEA Plugin Repository and you can download it directly from within IntelliJ IDEA.
For complete installation instructions and important information about the IntelliJ IDEA plugin, refer to 
http://gosu-lang.org/intellij.html


DOCUMENTATION AND EXAMPLES

The latest Gosu language documentation is at:
  http://www.gosu-lang.org/

Enjoy!